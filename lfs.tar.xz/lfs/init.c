
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/reboot.h>
#include <signal.h>
#include <sys/mount.h> // For mount()
#include <sys/stat.h>  // For mkdir()
#include <dirent.h>    // For opendir, readdir, etc.
#include <string.h>    // For strerror
#include <errno.h>     // For errno

// --- Configuration ---
// The primary shell to be launched. Place your cmd binary here in the ramdisk.
const char* SHELL_PATH = "/bin/shell";

// --- Function Prototypes ---
void mount_essential_filesystems();
void setup_device_permissions();
void handle_shutdown_signal(int sig);

int main(int argc, char* argv[]) {
    // Only run if we are PID 1
    if (getpid() != 1) {
        fprintf(stderr, "This program must be run as PID 1 (init).\n");
        return 1;
    }

    // --- Core System Setup ---
    mount_essential_filesystems();
    setup_device_permissions();

    // --- Signal Handling for reboot/poweroff ---
    signal(SIGTERM, handle_shutdown_signal); // Sent by 'shutdown' or 'reboot' commands
    signal(SIGINT, handle_shutdown_signal);  // Typically Ctrl+C, but can be sent manually

    printf("init: System setup complete. Starting shell.\n");

    // --- Main Loop: Respawn Shell ---
    while (1) {
        pid_t pid = fork();

        if (pid < 0) {
            // Fork failed, this is a serious error. Wait and retry.
            perror("init: fork failed");
            sleep(5);
            continue;
        }

        if (pid == 0) {
            // --- Child Process ---
            // Set up a minimal environment for the shell
            char* const args[] = {(char*)SHELL_PATH, NULL};
            char* const envp[] = {
                "HOME=/root",
                "PATH=/bin:/usr/bin:/sbin:/usr/sbin", // Standard LFS paths
                "TERM=linux", // Inform programs about the terminal type
                NULL
            };

            // Replace this child process with the shell
            execve(SHELL_PATH, args, envp);

            // If execve returns, it means an error occurred.
            perror("init: execve failed");
            exit(127); // Exit child with an error code
        } else {
            // --- Parent Process (PID 1) ---
            // Wait for the shell process to terminate
            waitpid(pid, NULL, 0);

            // Reap any other zombie processes that might have been created
            while(waitpid(-1, NULL, WNOHANG) > 0);

            // Short delay before respawning
            printf("init: Shell exited. Respawning in 2 seconds...\n");
            sleep(2);
        }
    }

    // This part should never be reached
    return 0;
}

void mount_essential_filesystems() {
    // Mount /proc for process information
    if (mount("proc", "/proc", "proc", 0, NULL) == -1) {
        perror("init: mount /proc failed");
    }

    // Mount /sys for kernel/driver information
    if (mount("sysfs", "/sys", "sysfs", 0, NULL) == -1) {
        perror("init: mount /sys failed");
    }

    // Mount /dev using devtmpfs to get device nodes automatically from the kernel
    if (mount("devtmpfs", "/dev", "devtmpfs", 0, NULL) == -1) {
        perror("init: mount /dev failed");
    }

    // Create and mount /dev/pts for pseudo-terminals (important for shells and terminals)
    mkdir("/dev/pts", 0755);
    if (mount("devpts", "/dev/pts", "devpts", 0, NULL) == -1) {
        perror("init: mount /dev/pts failed");
    }
}

void setup_device_permissions() {
    // After mounting /dev, device nodes should be present. Set their permissions.
    // This is CRITICAL for your terminal_fb and other low-level programs.
    if (chmod("/dev/console", 0666) == -1) {
        perror("init: chmod /dev/console failed");
    }

    if (chmod("/dev/graphics/fb0", 0666) == -1) {
        perror("init: chmod /dev/graphics/fb0 failed");
    }

    // Iterate through input devices and set their permissions
    DIR* d = opendir("/dev/input");
    if (d) {
        struct dirent* de;
        char path[256];
        while ((de = readdir(d)) != NULL) {
            if (strncmp(de->d_name, "event", 5) == 0) {
                snprintf(path, sizeof(path), "/dev/input/%s", de->d_name);
                if (chmod(path, 0666) == -1) {
                    // Not a fatal error, just print it
                    fprintf(stderr, "init: chmod on %s failed: %s\n", path, strerror(errno));
                }
            }
        }
        closedir(d);
    } else {
        perror("init: could not open /dev/input");
    }
}

void handle_shutdown_signal(int sig) {
    printf("\ninit: Shutdown signal (%d) received. Powering off.\n", sig);
    sync(); // Write any pending buffer cache to disk
    reboot(RB_POWER_OFF);
}
