/**
 * lfs-shell.c
 *
 * A simple, clean, and efficient shell for a minimal LFS environment.
 * - Displays a standard Linux-style prompt: user@host:path $
 * - Implements essential built-in commands: cd, pwd, echo, export, exit.
 * - Executes external commands from /bin and /sbin.
 *
 * To compile statically for Android (e.g., in Termux):
 * clang -o lfs-shell lfs-shell.c -static -Os -s -Wall -Wextra -L$PREFIX/lib
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>

// --- Definitions ---
#define CMD_BUF_SIZE 1024
#define MAX_ARGS 64
#define HOSTNAME "lfs" // The hostname we'll display in the prompt

// --- Function Prototypes ---
void print_prompt();
int execute_command(char* args[]);
int handle_builtin_command(char* args[]);

// --- Main Program Entry Point ---
int main() {
    char line_buf[CMD_BUF_SIZE];
    char* args[MAX_ARGS];
    char* token;

    // Optional: Print a welcome message once when the shell starts.
    printf("\nLFS Shell v1.0 -- Welcome to your minimal Linux environment.\n\n");

    while (1) {
        print_prompt();

        // Read a line of input from the user
        if (fgets(line_buf, sizeof(line_buf), stdin) == NULL) {
            if (feof(stdin)) { // Handle Ctrl+D
                printf("exit\n");
                break; // Exit the shell
            }
            // If there was another error, just continue the loop
            clearerr(stdin);
            continue;
        }

        // Remove trailing newline character
        line_buf[strcspn(line_buf, "\n")] = 0;

        // Skip empty commands
        if (strlen(line_buf) == 0) {
            continue;
        }

        // --- Tokenize the input string into arguments ---
        int i = 0;
        token = strtok(line_buf, " \t\r\n"); // Tokenize by space, tab, return, newline
        while (token != NULL && i < MAX_ARGS - 1) {
            args[i++] = token;
            token = strtok(NULL, " \t\r\n");
        }
        args[i] = NULL; // Null-terminate the argument list

        // If no command was entered (e.g., just spaces), continue
        if (args[0] == NULL) {
            continue;
        }

        // --- Execute the command ---
        execute_command(args);
    }

    return 0; // Exit the shell successfully
}

/**
 * @brief Prints the shell prompt, e.g., "root@lfs:/home/user $"
 */
void print_prompt() {
    char cwd[1024];
    char* user = getenv("USER");
    if (user == NULL) {
        // Fallback if USER is not set (e.g., very early boot)
        // Check effective user ID. 0 is root.
        user = (geteuid() == 0) ? "root" : "user";
    }

    if (getcwd(cwd, sizeof(cwd)) == NULL) {
        // If getting the current directory fails, default to "/"
        strcpy(cwd, "/");
    }

    // Use '#' for root, '$' for other users
    char prompt_end = (geteuid() == 0) ? '#' : '$';

    printf("%s@%s:%s %c ", user, HOSTNAME, cwd, prompt_end);
    fflush(stdout); // Ensure the prompt is displayed immediately
}

/**
 * @brief Determines if a command is built-in or external, and executes it.
 * @param args Null-terminated array of command-line arguments.
 * @return 0 on success, -1 on failure.
 */
int execute_command(char* args[]) {
    // First, check if it's a built-in command
    if (handle_builtin_command(args) == 0) {
        return 0; // Built-in command was handled
    }

    // --- If not built-in, treat as an external command ---
    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        return -1;
    }

    if (pid == 0) {
        // --- Child Process ---
        char full_path[1024];
        char* command = args[0];

        // If the command is an absolute path (starts with '/'), use it directly.
        if (command[0] == '/') {
            execv(command, args);
        } else {
            // Otherwise, search in our defined PATHs (/bin, then /sbin)
            snprintf(full_path, sizeof(full_path), "/bin/%s", command);
            execv(full_path, args);

            // If execv in /bin failed, try /sbin
            snprintf(full_path, sizeof(full_path), "/sbin/%s", command);
            execv(full_path, args);
        }

        // If execv returns, it means the command was not found or could not be executed.
        fprintf(stderr, "%s: command not found\n", args[0]);
        exit(127); // Standard exit code for "command not found"
    } else {
        // --- Parent Process (the shell) ---
        int status;
        // Wait for the child process to complete
        waitpid(pid, &status, 0);
    }

    return 0;
}

/**
 * @brief Handles built-in shell commands.
 * @param args Null-terminated array of command-line arguments.
 * @return 0 if the command was a handled built-in, -1 otherwise.
 */
int handle_builtin_command(char* args[]) {
    char* cmd = args[0];

    if (strcmp(cmd, "exit") == 0) {
        // Exit the shell. Can optionally take an exit code.
        int exit_code = 0;
        if (args[1] != NULL) {
            exit_code = atoi(args[1]);
        }
        exit(exit_code);
    }

    if (strcmp(cmd, "cd") == 0) {
        if (args[1] == NULL) {
            // 'cd' with no arguments usually goes to home directory
            char* home = getenv("HOME");
            if (home != NULL) {
                if (chdir(home) != 0) {
                    perror("cd");
                }
            }
        } else {
            if (chdir(args[1]) != 0) {
                perror("cd");
            }
        }
        return 0; // Command handled
    }

    if (strcmp(cmd, "pwd") == 0) {
        char cwd[1024];
        if (getcwd(cwd, sizeof(cwd)) != NULL) {
            printf("%s\n", cwd);
        } else {
            perror("pwd");
        }
        return 0; // Command handled
    }

    if (strcmp(cmd, "echo") == 0) {
        // Simple echo implementation
        for (int i = 1; args[i] != NULL; i++) {
            printf("%s%s", args[i], (args[i+1] != NULL) ? " " : "");
        }
        printf("\n");
        return 0; // Command handled
    }

    if (strcmp(cmd, "export") == 0) {
        // Simple 'export VAR=value' implementation
        if (args[1] == NULL) {
            // In a real shell, this would print all environment variables.
            // For simplicity, we'll just show usage.
            fprintf(stderr, "Usage: export VAR=value\n");
        } else {
            if (putenv(args[1]) != 0) {
                perror("export");
            }
        }
        return 0; // Command handled
    }

    // If we reach here, it's not a built-in command
    return -1;
}
